#include <unistd.h>

#include <iostream>

#include "JdkDecoder.hpp"
#include "JdkUsbCam.hpp"
#include "JdkVo.hpp"

int main(int argc, char *argv[]) {
	if (argc < 2) {
		std::cerr << "Usage: " << argv[0] << " <v4l2_device>\n";
		return -1;
	}
	std::string device = argv[1];
	int			width  = 1280;
	int			height = 720;

	auto camera = JdkUsbCam::create(device, width, height, V4L2_PIX_FMT_MJPEG);
	if (!camera) {
		std::cerr << "Failed to create camera\n";
		return -1;
	}
	auto decoder = std::make_shared<JdkDecoder>(width, height, CODING_MJPEG, PIXEL_FORMAT_NV12);
	auto jdkvo	 = std::make_shared<JdkVo>(width, height, PIXEL_FORMAT_NV12);

	for (int i = 0; i < 2000; ++i) {
		auto frame = camera->getFrame();
		if (!frame) {
			std::cerr << "Failed to capture frame " << i << "\n";
			continue;
		}
		auto decFrame = decoder->Decode(frame);
		auto ret	  = jdkvo->sendFrame(decFrame);

		printf("index:%d,dma_fd:%d width:%d,height:%d,size:%d\r\n", i,
			   decFrame->getDMAFd(), decFrame->getWidth(), decFrame->getHeight(), decFrame->getSize());
	}
	return 0;
}
