#include <unistd.h>

#include <iostream>

#include "JdkCamera.hpp"
#include "JdkVo.hpp"

int main(int argc, char *argv[]) {
	if (argc < 2) {
		std::cerr << "Usage: " << argv[0] << " <v4l2_device>\n";
		return -1;
	}
	std::string device = argv[1];

	auto camera = JdkCamera::create(device, 1920, 1080, V4L2_PIX_FMT_NV12);
	if (!camera) {
		std::cerr << "Failed to create camera\n";
		return -1;
	}
	auto jdkvo = std::make_shared<JdkVo>(1920, 1080, PIXEL_FORMAT_NV12);

	for (int i = 0; i < 2000; ++i) {
		auto frame = camera->getFrame();
		if (!frame) {
			std::cerr << "Failed to capture frame " << i << "\n";
			continue;
		}
		jdkvo->sendFrame(frame);
		printf("index:%d,dma_fd:%d width:%d,height:%d,size:%d\r\n", i, frame->getDMAFd(), frame->getWidth(), frame->getHeight(), frame->getSize());
	}
	return 0;
}
